﻿using ShellThumbs;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ShellThumbsDemo
{
    internal class Program
    {
        static void GetThumnail(string fileLoc, string thumbFileLoc, int height, int width)
        {
            Bitmap thumbnail = ShellThumbs.WindowsThumbnailProvider.GetThumbnail(fileLoc, height,width, ThumbnailOptions.None);
            thumbnail.Save(thumbFileLoc);
        }

        static void Main(string[] args)
        {
            string srcFileLoc = "", thumbFileLoc = "";
            int height = 512, width = 512;
            if (args.Length < 2)
            {
                return;
            }
            else if (args.Length == 2)
            {
                srcFileLoc = args[0];
                thumbFileLoc = args[1];
            }
            else if (args.Length == 3)
            {
                srcFileLoc = args[0];
                thumbFileLoc = args[1];
                height = int.Parse(args[2]);
                width = height;
            }
            else if (args.Length == 4)
            {
                srcFileLoc = args[0];
                thumbFileLoc = args[1];
                height = int.Parse(args[2]);
                width = int.Parse(args[3]);
            }
            GetThumnail(srcFileLoc, thumbFileLoc, height, width);
        }
    }
}
